import os
from collections import defaultdict

def get_file_extension_inventory(directory):
    """
    Recursively traverses a directory and takes an inventory of file extensions.

    Args:
        directory (str): The path of the directory to traverse.

    Returns:
        dict: A dictionary with file extensions as keys and counts as values.
    """
    extension_counts = defaultdict(int)

    for root, _, files in os.walk(directory):
        for file in files:
            _, ext = os.path.splitext(file)
            if ext:  # Only consider files with extensions
                extension_counts[ext] += 1

    return dict(extension_counts)

def print_inventory(inventory):
    """
    Prints the inventory of file extensions sorted by frequency in a readable format.

    Args:
        inventory (dict): Dictionary of file extensions and their counts.
    """
    print("File Extension Inventory:")
    for ext, count in sorted(inventory.items(), key=lambda item: item[1], reverse=True):
        print(f"{ext}: {count}")

if __name__ == "__main__":
    directory = input("Enter the directory to inventory: ").strip()

    if not os.path.isdir(directory):
        print(f"Error: {directory} is not a valid directory.")
    else:
        inventory = get_file_extension_inventory(directory)
        print_inventory(inventory)
