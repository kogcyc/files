from sys import argv
a = float(argv[1])
n = float(argv[2])
print(int(a*240 + n*600))
