import os

def count_files_and_size(directory):
    """
    Counts the number of files and calculates the total disk space used,
    excluding the .local and .cache directories.

    Args:
        directory (str): The path of the directory to analyze.

    Returns:
        tuple: A tuple containing the total number of files and the total size in bytes.
    """
    total_files = 0
    total_size = 0

    for root, dirs, files in os.walk(directory):
        # Skip .local and .cache directories
        dirs[:] = [d for d in dirs if d not in ['.local', '.cache']]

        for file in files:
            file_path = os.path.join(root, file)
            if os.path.isfile(file_path):
                total_files += 1
                total_size += os.path.getsize(file_path)

    return total_files, total_size

def print_summary(total_files, total_size):
    """
    Prints a summary of the file count and total disk space used.

    Args:
        total_files (int): The total number of files.
        total_size (int): The total size in bytes.
    """
    print(f"Total files: {total_files}")
    print(f"Total disk space used: {total_size / (1024 * 1024):.2f} MB")

if __name__ == "__main__":
    directory = input("Enter the directory to analyze: ").strip()

    if not os.path.isdir(directory):
        print(f"Error: {directory} is not a valid directory.")
    else:
        total_files, total_size = count_files_and_size(directory)
        print_summary(total_files, total_size)
