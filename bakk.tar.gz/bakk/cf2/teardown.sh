#!/bin/bash

# ANSI color codes for text styling
CYAN="\033[96m"
RED="\033[91m"
GREEN="\033[92m"
RESET="\033[0m"

# Prompt for the project directory name
echo -e "${CYAN}Please enter the name of the project directory to delete:${RESET} "
read -r project_name

# Confirm deletion
echo -e "${RED}This will permanently delete the '$project_name' directory and all its contents.${RESET}"
echo -e "${CYAN}Are you sure you want to proceed? (y/n):${RESET} "
read -r confirm

if [[ "$confirm" == "y" || "$confirm" == "Y" ]]; then
    # Check if the directory exists
    if [[ -d "$project_name" ]]; then
        # Remove the project directory and all its contents, except for setup.sh
        find "$project_name" -type f ! -name 'setup.sh' -exec rm -f {} +
        find "$project_name" -type d ! -path "$project_name" -exec rmdir {} +
        
        # Remove the main directory if it's empty
        rmdir "$project_name" 2>/dev/null

        echo -e "${GREEN}Project structure under '$project_name' has been successfully removed!${RESET}"
    else
        echo -e "${RED}Error: Directory '$project_name' does not exist.${RESET}"
    fi
else
    echo -e "${GREEN}Deletion canceled.${RESET}"
fi
