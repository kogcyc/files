import os

def find_files_with_extension(directory, extension):
    """
    Finds all files with a given extension in a directory and its subdirectories.

    Args:
        directory (str): The path of the directory to search.
        extension (str): The file extension to search for (e.g., '.txt').

    Returns:
        list: A sorted list of file paths with the specified extension.
    """
    matching_files = []

    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(extension):
                matching_files.append(os.path.join(root, file))

    return sorted(matching_files)

def print_sorted_file_list(file_list):
    """
    Prints a sorted list of file paths.

    Args:
        file_list (list): The list of file paths to print.
    """
    print("Sorted list of files:")
    for file_path in file_list:
        print(file_path)

if __name__ == "__main__":
    directory = input("Enter the directory to search: ").strip()
    extension = input("Enter the file extension to search for (e.g., '.txt'): ").strip()

    if not os.path.isdir(directory):
        print(f"Error: {directory} is not a valid directory.")
    else:
        file_list = find_files_with_extension(directory, extension)
        print_sorted_file_list(file_list)
