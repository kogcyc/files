import os
import shutil
import markdown
import frontmatter
import yaml

# Load configuration from config.yaml
def load_config():
    with open('config.yaml', 'r') as f:
        return yaml.safe_load(f)

# Manage the output directory
def setup_output_dir(output_dir):
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)  # Delete the directory if it exists
    os.makedirs(output_dir)  # Recreate the output directory

def generate_tiles(output_dir):
    tile_dir = os.path.join('src', 'tiles')
    tiles_html = ''
    
    for filename in os.listdir(tile_dir):
        if filename.endswith('.md'):
            with open(os.path.join(tile_dir, filename), 'r') as f:
                post = frontmatter.load(f)
                tiles_html += f"<div class='tile'><h2>{{post['title']}}</h2><p>{{post['desc']}}</p>{{markdown.markdown(post.content)}}</div>"

    with open(os.path.join('templates', 'index.html'), 'r') as f:
        index_template = f.read()
    final_html = index_template.replace('<!-- Tile content will be injected here -->', tiles_html)
    with open(os.path.join(output_dir, 'index.html'), 'w') as f:
        f.write(final_html)

def generate_articles(output_dir):
    article_dir = os.path.join('src', 'articles')
    articles_html = ''
    
    for filename in os.listdir(article_dir):
        if filename.endswith('.md'):
            with open(os.path.join(article_dir, filename), 'r') as f:
                post = frontmatter.load(f)
                articles_html += f"<div class='article'><h2>{{post['title']}}</h2><p>{{post['desc']}}</p>{{markdown.markdown(post.content)}}</div>"

    with open(os.path.join('templates', 'articles.html'), 'r') as f:
        articles_template = f.read()
    final_html = articles_template.replace('<!-- Article content will be injected here -->', articles_html)
    with open(os.path.join(output_dir, 'articles.html'), 'w') as f:
        f.write(final_html)

def generate_products(output_dir):
    product_dir = os.path.join('src', 'products')
    products_html = ''
    
    for filename in os.listdir(product_dir):
        if filename.endswith('.md'):
            with open(os.path.join(product_dir, filename), 'r') as f:
                post = frontmatter.load(f)
                products_html += f"<div class='product'><h2>{{post['title']}}</h2><p>{{post['desc']}}</p>{{markdown.markdown(post.content)}}</div>"

    with open(os.path.join('templates', 'products.html'), 'r') as f:
        products_template = f.read()
    final_html = products_template.replace('<!-- Product content will be injected here -->', products_html)
    with open(os.path.join(output_dir, 'products.html'), 'w') as f:
        f.write(final_html)

def main():
    config = load_config()
    output_dir = config['output_directory']
    
    # Set up the output directory
    setup_output_dir(output_dir)
    
    generate_tiles(output_dir)
    generate_articles(output_dir)
    generate_products(output_dir)
    print(f"Content generated successfully in '{output_dir}'")

if __name__ == "__main__":
    main()
