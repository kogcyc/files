#!/usr/bin/env python3
"""
Tissue — a small, readable static site generator.
"""

import os
import sys
import json
import shutil
import traceback
from pathlib import Path
from collections import defaultdict

import frontmatter
import markdown
from jinja2 import Environment, FileSystemLoader, TemplateError


# ============================================================
# Flags
# ============================================================

DEBUG   = bool(os.getenv("TISSUE_DEBUG"))
VERBOSE = True


# ============================================================
# Paths
# ============================================================

ROOT_DIR = Path(__file__).resolve().parent

MARKDOWN_DIR = ROOT_DIR / "markdown"
TEMPLATE_DIR = ROOT_DIR / "templates"
STATIC_DIR   = ROOT_DIR / "static"
BUILD_DIR    = ROOT_DIR / "public"


# ============================================================
# Sitemap
# ============================================================

sitemap_base_url = "http://127.0.0.1:8000"
sitemap_path = BUILD_DIR / "sitemap.xml"


# ============================================================
# Frontmatter keys
# ============================================================

REQUIRED_KEYS = {"title", "desc", "template"}
OPTIONAL_KEYS = {"image", "permalink", "collections", "collections_exclude"}
KNOWN_KEYS = REQUIRED_KEYS | OPTIONAL_KEYS


# ============================================================
# Helpers
# ============================================================

def validate_frontmatter(meta, path):
    missing = REQUIRED_KEYS - meta.keys()
    unknown = set(meta.keys()) - KNOWN_KEYS

    if missing:
        print(f"❌ {path} missing keys: {', '.join(missing)}")
        return False

    if unknown:
        print(f"⚠️  {path} unknown keys: {', '.join(unknown)}")

    return True


def generate_permalink(md_path):
    rel = md_path.relative_to(MARKDOWN_DIR)
    if rel.as_posix() == "index.md":
        return "/"
    return "/" + rel.with_suffix("").as_posix() + "/"


# ============================================================
# Build prep
# ============================================================

def prepare_build_dir():
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)


def copy_static():
    if STATIC_DIR.exists():
        shutil.copytree(STATIC_DIR, BUILD_DIR / "static")
        print("📁 Copied static assets.")
    else:
        print("⚠️  No static directory found.")


# ============================================================
# Index + collections
# ============================================================

def build_pages():
    pages = []
    skipped = 0

    for md_path in MARKDOWN_DIR.rglob("*.md"):
        post = frontmatter.load(md_path)

        if not validate_frontmatter(post.metadata, md_path):
            skipped += 1
            continue

        html = markdown.markdown(post.content)

        section = md_path.relative_to(MARKDOWN_DIR).parent.name or "root"

        collections = post.get("collections", [])
        if isinstance(collections, str):
            collections = [collections]

        excludes = post.get("collections_exclude", [])
        if isinstance(excludes, str):
            excludes = [excludes]

        page = {
            "title": post["title"],
            "desc": post["desc"],
            "image": post.get("image"),
            "template": post["template"],
            "permalink": post.get("permalink") or generate_permalink(md_path),
            "content": html,
            "section": section,
            "collections": collections,
            "collections_exclude": excludes,
        }

        pages.append(page)

    return pages, skipped


def build_collections(pages):
    collections = defaultdict(list)

    # folder-based collections
    for page in pages:
        collections[page["section"]].append(page)

    # frontmatter collections
    for page in pages:
        for name in page["collections"]:
            if name not in page["collections_exclude"]:
                collections[name].append(page)

    return collections


def report_collections(collections, pages):
    print("\n=== Collections built ===")

    folder_names = {
        p.relative_to(MARKDOWN_DIR).name
        for p in MARKDOWN_DIR.iterdir()
        if p.is_dir()
    }

    for name in sorted(collections):
        if name in folder_names:
            origin = "(folder)"
            star = ""
        elif name == "root":
            origin = "(implicit root-level)"
            star = "*"
        else:
            origin = "(frontmatter)"
            star = "*"

        print(f"  {name:<12} {star:<2} {origin}")


# ============================================================
# Rendering
# ============================================================

def render_pages(pages, collections, env):
    for page in pages:
        try:
            template = env.get_template(page["template"])
            rendered = template.render(
                this_page=page,
                all_pages=pages,
                site_collections=collections,
                **page,
            )
        except TemplateError as e:
            print(f"\n❌ Template error in {page['template']}: {e}")
            if DEBUG:
                traceback.print_exc()
            sys.exit(1)

        if page["permalink"] == "/":
            out = BUILD_DIR / "index.html"
        else:
            out = BUILD_DIR / page["permalink"].strip("/") / "index.html"

        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(rendered, encoding="utf-8")

        if VERBOSE:
            print(f"📝 Rendered {out.relative_to(BUILD_DIR)}")


# ============================================================
# Outputs
# ============================================================

def generate_search_index(pages):
    path = BUILD_DIR / "search_index.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(pages, f, indent=2)
    print(f"🔍 search_index.json written ({len(pages)} pages).")


def generate_sitemap(pages):
    entries = []
    for p in pages:
        url = sitemap_base_url.rstrip("/") + p["permalink"]
        entries.append(f"<url><loc>{url}</loc></url>")

    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        + "\n".join(entries)
        + "\n</urlset>\n"
    )

    sitemap_path.write_text(xml, encoding="utf-8")
    print(f"🗺️ sitemap.xml written ({len(entries)} URLs).")


# ============================================================
# Main
# ============================================================

def main():
    try:
        prepare_build_dir()
        copy_static()

        env = Environment(
            loader=FileSystemLoader(TEMPLATE_DIR),
            trim_blocks=True,
            lstrip_blocks=True,
        )

        pages, skipped = build_pages()
        collections = build_collections(pages)

        print(f"\nPages processed: {len(pages)}")
        print(f"Pages skipped due to invalid frontmatter: {skipped}")
        print(f"Collections total: {len(collections)}")

        if any(p["permalink"] == "/" for p in pages):
            print("🏠 Homepage found.")
        else:
            print("⚠️  No homepage (markdown/index.md).")

        report_collections(collections, pages)

        render_pages(pages, collections, env)
        generate_search_index(pages)
        generate_sitemap(pages)

        print("\n✨ Tissue build complete.\n")

    except Exception as e:
        print("\n❌ Tissue build failed:")
        print(f"{type(e).__name__}: {e}")
        if DEBUG:
            traceback.print_exc()
        else:
            print("\nTip: set TISSUE_DEBUG=1 for full traceback.")
        sys.exit(1)


if __name__ == "__main__":
    main()
