import machine
import neopixel
import time

num_leds = 64

# Initialize NeoPixel on GPIO 14
pin = machine.Pin(14)  # Create a pin object for GPIO 14
np = neopixel.NeoPixel(pin, num_leds)

while True:

  for i in range(num_leds):
    np[i] = (0, 0, 0)

  np.write()
    
  time.sleep(0.9)

  for i in range(num_leds):
    np[i] = (10, 20, 000)
     
  np.write()
     
  time.sleep(.1)
  

