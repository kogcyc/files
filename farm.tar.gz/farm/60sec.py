import machine
import neopixel
import time

num_leds = 64

# Initialize NeoPixel on GPIO 14
pin = machine.Pin(14)  # Create a pin object for GPIO 14
np = neopixel.NeoPixel(pin, num_leds)

for i in range(64):
  np[i] = (0, 0, 0)

pix = 1

while True:

  np[pix-1] = (0, 0, 4)

  np.write()

  pix = pix + 1
    
  time.sleep(1)

  if pix == 61:  
    for i in range(60):
      np[i] = (0, 0, 0)
    pix = 1 
     
  #np.write()
     
  #time.sleep(.1)
  

