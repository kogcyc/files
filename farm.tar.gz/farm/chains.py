def sprocket_center_distance_mm(teeth1, teeth2, link_count, pitch_mm=12.7):
    """
    Approximate the center-to-center distance between two sprockets in millimeters.

    Parameters:
        teeth1 (int): Number of teeth on sprocket 1.
        teeth2 (int): Number of teeth on sprocket 2.
        link_count (int): Total number of chain links.
        pitch_mm (float): Chain pitch in millimeters (default is 12.7mm for standard 1/2" chain).

    Returns:
        float: Center-to-center distance in millimeters.
    """
    N1 = teeth1
    N2 = teeth2
    L = link_count

    # Center distance in pitches
    C_pitches = (L - 0.5 * (N1 + N2)) / 2

    # Convert to millimeters
    return C_pitches * pitch_mm

sp1 = 11
sp2 = 42
for t in range(60,112,2):
  distance_mm = sprocket_center_distance_mm(sp1, sp1, t)
  print(f"{sp1}:{sp2}:{t} {distance_mm:.0f} mm")
